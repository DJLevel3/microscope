/**
 * Copyright (c) 2015-2024, Martin Roth (mhroth@gmail.com)
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
 * INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
 * LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
 * OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
 * PERFORMANCE OF THIS SOFTWARE.
 */



#ifndef _TINY_WAV_
#define _TINY_WAV_

#define TINYWAV_USE_MALLOC 1

#include "system.h"

// http://soundfile.sapp.org/doc/WaveFormat/

typedef struct TinyWavHeader {
  char ChunkID[4];
  uint32_t ChunkSize;
  char Format[4];
  char Subchunk1ID[4];
  uint32_t Subchunk1Size;
  uint16_t AudioFormat;
  uint16_t NumChannels;
  uint32_t SampleRate;
  uint32_t ByteRate;
  uint16_t BlockAlign;
  uint16_t BitsPerSample;
  char Subchunk2ID[4];
  uint32_t Subchunk2Size;
} TinyWavHeader;

typedef struct TinyWav {
  FILE *f;
  TinyWavHeader h;
  int16_t numChannels;
  int32_t numFramesInHeader; ///< number of samples per channel declared in wav header (only populated when reading)
  uint32_t totalFramesReadWritten; ///< total numSamples per channel which have been read or written
} TinyWav;

/**
 * Open a file for reading.
 *
 * @param path     The path of the file to read.
 * @param chanFmt  The desired channel format (how the channel data is layed out in memory) when read.
 *
 * @return  The sample rate, or zero if there was an error.
 */
unsigned int tinywav_open_read(TinyWav *tw, const char *path);

/**
 * Read sample data from the file.
 *
 * @param tw   The TinyWav structure which has already been prepared.
 * @param data  A pointer to the data structure to read to. This data is expected to have the
 *              correct memory layout to match the specifications given in tinywav_open_read().
 * @param len   The number of frames (samples per channel) to read.
 *
 * @return The number of frames (samples per channel) read from file.
 */
int tinywav_read_f(TinyWav *tw, void *data, int len);
  

#endif // _TINY_WAV_
